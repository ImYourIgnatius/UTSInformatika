const kBottomNavigationBarItemSize = 24.0;
const kCategoryCardImageSize = 120.0;
